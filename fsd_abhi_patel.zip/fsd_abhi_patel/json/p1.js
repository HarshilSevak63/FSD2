// data type =>1.string ,2.number,3.boolean,4.Array,5.object,6.null
//function ,date,undefind not data-type of json
fetch("json/p1.json")
    