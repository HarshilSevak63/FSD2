// 

const os = require('os')
const path = require("path")

var s = "D:/fsd_patel/test/g.txt";
console.log(path.dirname(s));
console.log(path.basename(s))
console.log(path.extname(s));

var p = path.parse(s);
console.log(p);
console.log(p.root)

//check if a given file is an image (png,jpg,gif) or not 
var c = path.extname(s);
if(c == '.jpg'){
    console.log("che it is ..")
}
else{
    console.log("nathi..")
}