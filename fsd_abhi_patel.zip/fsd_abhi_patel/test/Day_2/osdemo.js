const os= require('os');
const fs = require('fs');

console.log(" archi"+ os.arch());
console.log("platform: "+ os.platform());
console.log("host: "+ os.hostname());
console.log("temp dir: "+ os.tmpdir());
console.log("free memory : "+ os.freemem()/1024/1024/1024);
console.log("total memory: "+ os.totalmem());


// create a folder aa in temp dir . If available free memory is greater then 1 gb write in a text file of this 
//folder - memory sufficient else write insufficient memory

var f =os.tmpdir();
fs.mkdirSync(f + "//AA");
var fr = os.freemem/1024/1024/1024;
if(fr>1){
    fs.writeFileSync(f+"//AA//a.txt","sufficient..");
}
else{
    fs.writeFileSync(f+"//AA//a.txt","not..");
}
console.log(fs.readFileSync(f+"//AA//a.txt", 'UTF-8'));

