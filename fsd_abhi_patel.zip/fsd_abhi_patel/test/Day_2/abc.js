 const fs = require("fs");

cb=(err)=>{
    if(err){
        console.log("not written");
    }
    else{
        console.log("file written")
    }
};
// fs.mkdir("test1",cb);


//fs.writeFile("test1/Hetvi1.txt","please God trying vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv",cb);
// function ap()
//     {
//         fs.appendFile("test1/Hetvi1.txt"," a1",(err)=>{
//         if(err){
//             console.log("not append" + err);
//         }
//         else{
//             console.log("file appended");
//         }
//         });}
// setTimeout(ap,2000);

// fs.rename("test1/Hetvi1.txt","test1/DemoH.txt",cb);

// fs.unlink("test1/Het.txt",cb) ;
// fs.rmdir("t",cb);  // to remove folder but it should be empty 


//              read file

// fs.readFile("test1/Hetvi.txt", (err,data)=>{
//     if(err){
//         console.log("not exist so will not read");
//     }
//     else{
//         console.log(data.toString() );
//         console.log(data);
        
//     }
// });

fs.readFile("test1/Hetvi.txt","UTF-8", (err,data)=>{
    if(err){
        console.log("not exist so will not read");
    }
    else{
        console.log(data);
    }
});

