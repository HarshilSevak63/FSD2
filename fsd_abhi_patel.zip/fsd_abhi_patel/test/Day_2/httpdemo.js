//              STEPS TO CREATE SERVER AND FULFILL REQUEST

//  1. Require http module
//  2. Create a server  [ 1.Handle request  2. Write head  3.Give Response  4.End response]
//  3. Configure your server to listen to a particular port 

// 1xx no response  2xx ok  3xx server eror  4XX client  5XX redirection

// Name - contentType
// html - text/html
// css - text/css
// js -  application/javascript
// json - application/json
// image jpg - image/jpg  ( png or jpeg ...)

const http = require('http');
var myserver =  http.createServer((req,res)=>{


    // console.log(req.url);
    if(req.url =='/'){
        res.writeHead(200, {'Content-Type':'text/html'});
        res.write("<h2>Good Morning </h2>");
        res.write("Hello ..");
    }
    
    else{
        res.writeHead(404, {'Content-Type':'text/html'});
        res.write('<h2 style="color:red;" > Page Not Found </h2>');
    }
    res.end();

});

myserver.listen(5000);
console.log("listening to port 5000 ...")  // 127.1.0.0:5000   or  localhost:5000 
// console.log(Math.pow(2,16));



//