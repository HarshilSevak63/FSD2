const url = require('url')
const http = require('http')
const fs = require('fs')


// From the given url redirect to require html page if it exists else display client error 

http.createServer((req,res)=>{

    var p =url.parse(req.url);
     // console.log(req.url);
    //  if(p.pathname =='/index.html' || p.pathname =='/about.html' || p.pathname =='/contact.html'){
    //     res.writeHead(200, {'Content-Type':'text/html'});
    //     res.write(fs.readFileSync('.'+ p.pathname.toString()));
    // }
   
    if(fs.existsSync('.' + p.pathname) || p.pathname =='/'){
        res.writeHead(200, {'Content-Type':'text/html'});
        res.write(fs.readFileSync('.'+ p.pathname.toString()));
    }
    // else if(p.pathname =='/'){
    //     res.writeHead(404, {'Content-Type':'text/html'});
    //     res.write(fs.readFileSync('.'+ '/index.html'.toString()));

    // }
    else{
        res.writeHead(404, {'Content-Type':'text/html'});
        res.write('<h2 style="color:red;" > Page Not Found </h2>');
    }
    res.end();

}).listen(5003, ()=>{console.log("listening.  ...")});