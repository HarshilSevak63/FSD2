// library mean's module
//  fs is inbuild module and it will be in comman javascript
//  FS fileSystem
// what can fs Sync do is :-
// 1) create a folder ,
// 2) create a file ,
// 3) if you write a file  and if it not exist then it create it
// 4) appened it will also create an new file if not present
// 5) read file and for that file must be present else error
// 6) rename file
// 7) delete file
// 8) delete the folder but it must be empty

//  in async:- it will go for the one which take less time and
//  in case of error it run everything that is error free first and then it will show error
//  main difference in this is that if a function is dependent on other fnction
//  then it may create an deadlock
//  so we have to write a callback function in it

//  all sync step
// 1)const fs=require('fs'); to store it in a object to access it
// 2)fs.mkdirSync("./"); here "./ " or "test " means to make it in current director
const fs = require("fs");
fs.mkdirSync("test"); // to make a folder
// fs.mkdirSync("abc/test");// can't make a folder inside folder not like this
// fs.mkdirSync("abc/test", { recursive: true }); // to make a folder inside can be done like this

// now to make on a fix path
// fs.mkdirSync("D://Radhe//test2");

//3)  now we will try to write a file
//syntax:- fs.writeFileSync(Path,value to write)
// fs.writeFileSync("test/a.txt", "Radhe Radhe");
//  on doing it 2nd time it will replace it

//4) now we will be appending it
// fs.appendFileSync("test/a.txt", " Hello World added it using append");

//5)  now we will be reading the file
// console.log(fs.readFileSync("test/a.txt"));
//  this give a buffer file that is in raw format so we need to convert it to string

// method 1
// console.log(fs.readFileSync("test/a.txt").toString());// one method is by using toSting()

// method 2 this is readign a file without usoing buffer
// console.log(fs.readFileSync("test/a.txt", "utf-8"));
// console.log(fs.readFileSync("test/a.txt", "UTF-8"));

//6)  now we will be renameing the file
// fs.renameSync("test/c.txt", "test/e.txt");

//7)  now for deleting a file
// fs.unlinkSync("test/e.txt");

//8)  now for deleting the folder
fs.rmdirSync("test"); // make sure to make the folder empty
