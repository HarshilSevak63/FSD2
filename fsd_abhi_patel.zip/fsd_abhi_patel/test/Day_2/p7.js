// write  a script to read a simple html file using server 

const fs = require('fs')
const http = require('http')

var myserver =  http.createServer((req,res)=>{
    if(req.url =='/'){
        res.writeHead(200, {'Content-Type':'text/html'});
       var c=  fs.readFileSync("D://fsd_abhi_patel//test//Day_2//home.html").toString()
        res.write(c);
        
    }
    
    else{
        res.writeHead(404, {'Content-Type':'text/html'});
        res.write('<h2 style="color:red;" > Page Not Found </h2>');
    }
    res.end();
});
myserver.listen(5002);
console.log("listening to port 5002 ...")