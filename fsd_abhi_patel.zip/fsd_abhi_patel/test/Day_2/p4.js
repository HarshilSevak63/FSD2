//  callback function

// 1) setTimeout(function name,1000[time in mile second]) :- 
// it will be called ones after the time has passed
// 2) setInterval(function name,1000) :-
//  here it will be called infinitely after every time duration
// and to stop that we wil use clearInterval("abc") or ctrl+c

// pratice question
// create a js code to display 3 messages but in reverse order in which they are written

function f() {
  console.log("Bye Bye buddy !!");
}
// setTimeout(f,3000);// can't pass parameter like f(dhruvi)
//  for that we will create an nameless function

// method 1
// setTimeout(function (dhruv)=>{
//     ...
//     return dhruv
// },2000)

// Method 2 using fat arrow function
// setTimeout(()=>console.log("How are you doing ?"),2000)
// setTimeout(() => console.log("I am Radhe"), 1000);
console.log("HI");

//  pratics question 2
//  write a js code and create a es6 function that add 2 number which are incremented every one second
// and their output is displayed
a = 2;
b = 3;
setInterval(() => {
  c = a + b;
  console.log("sum is ", c, "Here value pf a & b are ", a, "&", b);
  a = a + 1;
  b = b + 1;
  console.log("incremented a", a, "incremeted b", b);
}, 1000);
//  madam's method
add1=(a,b)=>console.log(a+b);
setInterval(()=>add1(++a,++b),1000);
