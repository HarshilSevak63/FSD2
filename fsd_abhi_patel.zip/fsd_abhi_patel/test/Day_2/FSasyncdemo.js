const fs = require("fs");
// 1) to make a folder
// fs.mkdir("test1", (err) => {
//   //  if this if is not there then it will print null
//   if (err) {
//     console.log(err);
//   } else {
//     console.log("Folder created successfully ");
//   }
// });
console.log("Radhe Radhe"); // it comes first because it take less time and error free too
// fs.mkdir("abc/test", (err) => {
//   //  if this if is not there then it will print null
//   if (err) {
//     console.log(err);
//   } else {
//     console.log("Folder created successfully ");
//   }
// });// can't make a folder inside folder not like this
// fs.mkdir("abc/test", { recursive: true }, (err) => {
//   //  if this if is not there then it will print null
//   if (err) {
//     console.log(err);
//   } else {
//     console.log("Folder created successfully ");
//   }
// }); // to make a folder inside can be done like this

// now to make on a fix path
// fs.mkdir("D://Radhe//test2", (err) => {
//   //  if this if is not there then it will print null
//   if (err) {
//     console.log(err);
//   } else {
//     console.log("Folder created successfully ");
//   }
// });

//  now we will try to write a file
//syntax:- fs.writeFile (Path,value to write)
// fs.writeFile("test1/a.txt", "Radhe Radhe", (err) => {
//   //  if this if is not there then it will print null
//   if (err) {
//     console.log(err);
//   } else {
//     console.log("written successfully ");
//   }
// });
//  on doing it 2nd time it will replace it

// now we will be appending it
// fs.appendFile("test1/a.txt", " Hello World added it using append", (err) => {
//   //  if this if is not there then it will print null
//   if (err) {
//     console.log(err);
//   } else {
//     console.log("appened successfully ");
//   }
// });

//  this is still to be done by maam
//  now we will be reading the file
// console.log(fs.readFile("test/a.txt"));
//  this give a buffer file that is in raw format so we need to convert it to string

// method 1
// console.log(fs.readFile("test/a.txt").toString());// one method is by using toSting()

// method 2 this is readign a file without usoing buffer
// console.log(fs.readFile ("test/a.txt", "utf-8"));
// console.log(fs.readFile("test/a.txt", "UTF-8"));

//  now we will be renameing the file
// fs.rename("test1/a.txt", "test1/e.txt", (err) => {
//   //  if this if is not there then it will print null
//   if (err) {
//     console.log(err);
//   } else {
//     console.log("rename successfully ");
//   }
// });

//  now for deleting a file
// fs.unlink("test1/e.txt", (err) => {
//   //  if this if is not there then it will print null
//   if (err) {
//     console.log(err);
//   } else {
//     console.log("File deleted successfully ");
//   }
// });

//  now for deleting the folder
// fs.rmdir("test1", (err) => {
//   //  if this if is not there then it will print null
//   if (err) {
//     console.log(err);
//   } else {
//     console.log("Folder deleted successfully ");
//   }
// }); // make sure to make the folder empty
