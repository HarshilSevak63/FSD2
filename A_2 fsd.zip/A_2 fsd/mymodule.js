function print( msg){
    console.log("Hi from mymodule " + msg);
}

function add(a,b){
    console.log("addition is " + (a+b));
}
function sub(a,b){
    console.log("addition is "+ (a-b));
}
module.exports.p = print;
module.exports.a = add;
module.exports.s = sub;