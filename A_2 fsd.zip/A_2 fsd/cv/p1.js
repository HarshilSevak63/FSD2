//  WAS to check in the query string of a url entered by user weather email id is valid or not . If it is valid 
// write in a file a.txt url has valid email else invalid email . Read this file and print data in magenta color


import fs from 'fs';
import chalk  from 'chalk';
import v from 'validator';
import http from 'http';
import url from 'url';

// var myurl = "http://localhost:80/abc/test/home.html?email=ab@c.co";

 var mysql=  http.createServer((req,res)=>{
    var q = url.parse(req.url,true);  
    var qry = q.query;
    if(v.isEmail(qry.email)){
        fs.writeFileSync("a.txt", "Email is valid..");
    }
    
    else{
        fs.writeFileSync("a.txt", "Email is not valid..");
    }
    res.end();

});mysql.listen(5004, ()=>{console.log("listening. in 5004  ...")});

var us = fs.readFileSync("a.txt").toString();
console.log(chalk.magenta(us));
