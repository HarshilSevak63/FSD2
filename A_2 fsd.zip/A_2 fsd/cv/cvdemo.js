import chalk from "chalk";

console.log(chalk.red.bgYellow.italic("Hello Hi World"));
console.log(chalk.bgYellowBright("FSD"));
console.log(chalk.italic("Italic"));
console.log(chalk.underline("Underline"));
console.log(chalk.bold("bold"));
console.log(chalk.overline("overline"));


import v from  'validator';

if(v.isEmail('ht@ab.co')){
    console.log(chalk.greenBright("Is Valid email"));
}
else{
    console.log(chalk.redBright("invalid email"));
}
console.log(v.isURL("www.google.com")? chalk.green("It is valid url") : (chalk.red("Not valid URL")) );

console.log(v.isEmpty(" ")? chalk.green("Is empty") : chalk.red("not empty"));
