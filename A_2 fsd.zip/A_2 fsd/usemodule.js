const m = require("./mymodule.js");

m.p("My message");
m.a(1,5);
m.s(20,10);